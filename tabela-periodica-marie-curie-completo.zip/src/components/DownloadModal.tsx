import React from 'react';
import { Download, X, FolderArchive, CheckCircle2, FileCode, Globe, Sparkles, HelpCircle } from 'lucide-react';

interface DownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  isHighContrast: boolean;
}

export const triggerProjectDownload = () => {
  const link = document.createElement('a');
  link.href = '/tabela-periodica-marie-curie-completo.zip';
  link.setAttribute('download', 'tabela-periodica-marie-curie-completo.zip');
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export const DownloadModal: React.FC<DownloadModalProps> = ({
  isOpen,
  onClose,
  isHighContrast,
}) => {
  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="titulo-download-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-sm animate-fadeIn"
      onClick={onClose}
    >
      <div
        className={`relative w-full max-w-2xl max-h-[92vh] flex flex-col rounded-3xl border-4 shadow-2xl overflow-hidden transition-all ${
          isHighContrast
            ? 'bg-black text-yellow-300 border-white'
            : 'bg-white text-slate-900 border-emerald-300'
        }`}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Cabeçalho */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b-2 border-slate-100 dark:border-white/20 bg-emerald-50 dark:bg-neutral-900 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center text-2xl font-black shadow-md">
              <Download className="w-6 h-6" />
            </div>
            <div>
              <h2 id="titulo-download-modal" className="text-xl sm:text-2xl font-black text-emerald-800 dark:text-yellow-300 m-0">
                Baixar Site e Código-Fonte Completo
              </h2>
              <p className="text-xs sm:text-sm font-bold text-slate-600 dark:text-yellow-100 m-0">
                Pacote .ZIP com absolutamente tudo do projeto (HTML, Código, Imagens e Configurações).
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar janela de download"
            className="p-2.5 rounded-2xl bg-slate-200 hover:bg-rose-500 hover:text-white dark:bg-neutral-800 dark:hover:bg-rose-600 text-slate-700 dark:text-white border-2 border-slate-300 dark:border-white cursor-pointer transition-all active:scale-95"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Conteúdo */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5">
          {/* Botão Principal de Download Imediato */}
          <div className="text-center p-5 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-600 to-indigo-600 text-white shadow-lg">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 text-xs font-black mb-3">
              <Sparkles className="w-4 h-4 text-yellow-300" />
              <span>Pacote Completo (.ZIP) Pronto para Download</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-black mb-2">
              Clique no botão abaixo para baixar tudo
            </h3>
            <p className="text-xs sm:text-sm text-emerald-100 max-w-lg mx-auto mb-4 font-medium">
              O arquivo contém o código-fonte em React/TypeScript, os arquivos HTML já compilados para publicar e todos os assets.
            </p>
            <button
              type="button"
              onClick={triggerProjectDownload}
              className="px-6 py-3.5 rounded-2xl bg-yellow-400 hover:bg-yellow-300 text-slate-900 font-black text-base sm:text-lg shadow-xl hover:scale-105 active:scale-95 cursor-pointer transition-all inline-flex items-center gap-2.5 border-2 border-yellow-200"
            >
              <Download className="w-6 h-6 text-slate-900" />
              <span>Baixar Tudo Agora (.ZIP)</span>
            </button>
          </div>

          {/* O que está incluído no arquivo */}
          <div className="space-y-3">
            <h4 className="text-base sm:text-lg font-black text-slate-800 dark:text-yellow-300 flex items-center gap-2">
              <FolderArchive className="w-5 h-5 text-emerald-600 dark:text-yellow-400" />
              <span>O que está dentro do arquivo ZIP baixado:</span>
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs sm:text-sm font-bold">
              <div className="p-3.5 rounded-xl border-2 border-slate-200 dark:border-white/30 bg-slate-50 dark:bg-neutral-900 space-y-1">
                <div className="flex items-center gap-1.5 text-emerald-600 dark:text-yellow-300 font-black">
                  <Globe className="w-4 h-4" />
                  <span>Site Compilado (Pasta dist/)</span>
                </div>
                <p className="text-slate-600 dark:text-yellow-100 font-normal">
                  Contém o <code>index.html</code>, arquivos CSS e JS prontos para publicar no GitHub Pages, Vercel ou hospedar diretamente.
                </p>
              </div>

              <div className="p-3.5 rounded-xl border-2 border-slate-200 dark:border-white/30 bg-slate-50 dark:bg-neutral-900 space-y-1">
                <div className="flex items-center gap-1.5 text-indigo-600 dark:text-yellow-300 font-black">
                  <FileCode className="w-4 h-4" />
                  <span>Código-Fonte Completo (Pasta src/)</span>
                </div>
                <p className="text-slate-600 dark:text-yellow-100 font-normal">
                  Todos os 118 elementos químicos cadastrados, componentes React, scripts de voz e estilos Tailwind.
                </p>
              </div>

              <div className="p-3.5 rounded-xl border-2 border-slate-200 dark:border-white/30 bg-slate-50 dark:bg-neutral-900 space-y-1">
                <div className="flex items-center gap-1.5 text-purple-600 dark:text-yellow-300 font-black">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Imagens e Mídias</span>
                </div>
                <p className="text-slate-600 dark:text-yellow-100 font-normal">
                  Pintura e retratos históricos em homenagem a Marie Curie e ícones em alta resolução.
                </p>
              </div>

              <div className="p-3.5 rounded-xl border-2 border-slate-200 dark:border-white/30 bg-slate-50 dark:bg-neutral-900 space-y-1">
                <div className="flex items-center gap-1.5 text-amber-600 dark:text-yellow-300 font-black">
                  <HelpCircle className="w-4 h-4" />
                  <span>Manual e Configurações</span>
                </div>
                <p className="text-slate-600 dark:text-yellow-100 font-normal">
                  <code>package.json</code>, <code>vite.config.ts</code> e o <code>README.md</code> completo com passo a passo.
                </p>
              </div>
            </div>
          </div>

          {/* Dica de como rodar no seu computador */}
          <div className="p-4 rounded-2xl bg-amber-50 dark:bg-neutral-900 border-2 border-amber-200 dark:border-white/30 space-y-2">
            <h5 className="text-xs sm:text-sm font-black text-amber-900 dark:text-yellow-300">
              💡 Como rodar no seu computador após descompactar:
            </h5>
            <ol className="list-decimal list-inside text-xs sm:text-sm text-slate-700 dark:text-yellow-100 space-y-1 font-mono">
              <li>Descompacte o arquivo <code>tabela-periodica-marie-curie-completo.zip</code></li>
              <li>Abra o terminal na pasta e execute: <code>npm install</code></li>
              <li>Inicie o site localmente com: <code>npm run dev</code></li>
              <li>Para gerar novo HTML estático: <code>npm run build</code></li>
            </ol>
          </div>
        </div>

        {/* Rodapé */}
        <div className="p-3.5 sm:p-4 bg-slate-100 dark:bg-neutral-950 border-t-2 border-slate-200 dark:border-white/20 flex items-center justify-between">
          <span className="text-xs font-bold text-slate-500 dark:text-yellow-200">
            Tabela Periódica Adaptada Marie Curie
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 text-white dark:bg-yellow-300 dark:text-black font-black text-xs sm:text-sm cursor-pointer hover:bg-slate-700"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
