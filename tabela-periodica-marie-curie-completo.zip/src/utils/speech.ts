export interface SpeakOptions {
  rate?: number;
  pitch?: number;
  onStart?: () => void;
  onEnd?: () => void;
  onError?: (e: any) => void;
}

// Cache local de vozes e controle de inicialização assíncrona
let cachedVoices: SpeechSynthesisVoice[] = [];
let isVoiceInitialized = false;

function carregarVozes(): SpeechSynthesisVoice[] {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return [];
  }
  try {
    const vozes = window.speechSynthesis.getVoices();
    if (vozes && vozes.length > 0) {
      cachedVoices = vozes;
    }
  } catch {
    // Falha silenciosa caso bloqueado por iframe
  }
  return cachedVoices;
}

// Inicializar escuta do evento onvoiceschanged imediatamente
if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
  carregarVozes();
  if (window.speechSynthesis.onvoiceschanged !== undefined) {
    window.speechSynthesis.onvoiceschanged = () => {
      carregarVozes();
      isVoiceInitialized = true;
    };
  }
}

/**
 * Seleciona com precisão a melhor voz disponível em Português do Brasil (pt-BR)
 */
export function getMelhorVozPortuguesBrasil(): SpeechSynthesisVoice | null {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    return null;
  }

  let vozes = cachedVoices;
  if (!vozes || vozes.length === 0) {
    vozes = carregarVozes();
  }

  if (!vozes || vozes.length === 0) {
    return null;
  }

  // Função de pontuação para priorizar Português do Brasil
  const pontuarVoz = (voz: SpeechSynthesisVoice): number => {
    const lang = (voz.lang || '').toLowerCase().replace(/_/g, '-');
    const name = (voz.name || '').toLowerCase();

    let pontuacao = 0;

    // 1. Verificação primária: É explicitamente pt-BR?
    const isPtBR = lang === 'pt-br' || lang.startsWith('pt-br');
    const isBrasilNoNome = name.includes('brasil') || name.includes('brazil') || name.includes('pt-br');

    if (isPtBR) {
      pontuacao += 100;
    } else if (isBrasilNoNome) {
      pontuacao += 80;
    } else if (lang.startsWith('pt')) {
      // Português não-especificado ou de outra região (usar apenas se não houver pt-BR)
      pontuacao += 30;
      if (lang.includes('pt-pt') || name.includes('portugal')) {
        pontuacao -= 15; // Penaliza pt-PT para preferir pt-BR
      }
    } else {
      return -1; // Não é português
    }

    // 2. Bônus para vozes naturais e de alta qualidade (Google, Microsoft, Apple, Android)
    if (name.includes('natural') || name.includes('online')) pontuacao += 15;
    if (name.includes('google')) pontuacao += 12;
    if (name.includes('luciana') || name.includes('felipe') || name.includes('francisca') || name.includes('antonio')) pontuacao += 10;
    if (name.includes('leticia') || name.includes('heloisa') || name.includes('yara') || name.includes('maria')) pontuacao += 8;
    if (voz.default) pontuacao += 5;

    return pontuacao;
  };

  const vozesPontuadas = vozes
    .map(voz => ({ voz, score: pontuarVoz(voz) }))
    .filter(item => item.score > 0)
    .sort((a, b) => b.score - a.score);

  return vozesPontuadas.length > 0 ? vozesPontuadas[0].voz : null;
}

/**
 * Normaliza e ajusta texto para pronúncia limpa e fluente em Português do Brasil
 */
export function formatarTextoParaPronunciaPtBR(texto: string): string {
  if (!texto) return '';

  return texto
    // Abreviações numéricas comuns
    .replace(/\bNº\b/g, 'Número')
    .replace(/\bnº\b/g, 'número')
    .replace(/\bNº\s*Atômico\b/gi, 'Número Atômico')
    .replace(/\bNº\s*de\s*Massa\b/gi, 'Número de Massa')
    .replace(/\bZ\s*=\s*/g, 'Número atômico Z igual a ')
    .replace(/\bA\s*=\s*/g, 'Número de massa A igual a ')
    // Unidades e símbolos químicos
    .replace(/g\/cm³/gi, 'gramas por centímetro cúbico')
    .replace(/°C\b/g, 'graus Celsius')
    // Símbolo químico destacado
    .replace(/\bSímbolo:\s*([A-Z][a-z]?)\b/g, 'Símbolo: $1.')
    // Pausas adequadas para pontuação
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Executa a narração do texto garantindo Português do Brasil
 */
export function speakText(text: string, options: SpeakOptions = {}): void {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    console.warn('Síntese de voz não suportada neste navegador.');
    return;
  }

  // Cancelar áudios em andamento antes de iniciar novo
  window.speechSynthesis.cancel();

  if (!text || text.trim() === '') return;

  const textoFormatado = formatarTextoParaPronunciaPtBR(text);

  // Pequeno timeout assíncrono para contornar bug do Chromium onde cancel() imediato anula o speak() subsequente
  setTimeout(() => {
    try {
      const utterance = new SpeechSynthesisUtterance(textoFormatado);
      
      // Forçar sempre a linguagem Português do Brasil
      utterance.lang = 'pt-BR';
      utterance.rate = options.rate ?? 0.9;
      utterance.pitch = options.pitch ?? 1.0;

      // Buscar voz brasileira de alta fidelidade
      const vozPtBR = getMelhorVozPortuguesBrasil();
      if (vozPtBR) {
        utterance.voice = vozPtBR;
      }

      if (options.onStart) {
        utterance.onstart = options.onStart;
      }
      if (options.onEnd) {
        utterance.onend = options.onEnd;
      }
      if (options.onError) {
        utterance.onerror = (e) => {
          // Ignorar erros decorrentes de interrupção intencional (cancel)
          if (e.error !== 'interrupted' && e.error !== 'canceled') {
            console.warn('Aviso de síntese de voz:', e.error);
          }
          if (options.onError) {
            options.onError(e);
          }
        };
      }

      window.speechSynthesis.speak(utterance);
    } catch (err) {
      console.warn('Erro ao reproduzir voz:', err);
      if (options.onError) {
        options.onError(err);
      }
    }
  }, 20);
}

export function stopSpeaking(): void {
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    try {
      window.speechSynthesis.cancel();
    } catch {
      // Ignora erro ao cancelar
    }
  }
}

/**
 * Retorna informações sobre a voz atualmente selecionada para o Português do Brasil
 */
export function getInfoVozPtBR(): { nome: string; lang: string; disponivel: boolean } {
  const voz = getMelhorVozPortuguesBrasil();
  if (voz) {
    return {
      nome: voz.name,
      lang: voz.lang,
      disponivel: true,
    };
  }
  return {
    nome: 'Padrão do Sistema (pt-BR)',
    lang: 'pt-BR',
    disponivel: typeof window !== 'undefined' && 'speechSynthesis' in window,
  };
}

