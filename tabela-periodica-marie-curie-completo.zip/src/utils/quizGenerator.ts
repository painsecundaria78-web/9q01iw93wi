import { QuizQuestion, ChemicalElement } from '../types';
import { ELEMENTOS_QUIMICOS } from '../data/elements';

// Banco amplo de perguntas temáticas do cotidiano - Adaptado para alunos do Ensino Médio com TEA Grau 3
// Linguagem direta, apoio visual com emojis, foco concreto em objetos e situações do dia a dia, sem dicas confusas
export const BANCO_PERGUNTAS_BASE: QuizQuestion[] = [
  {
    id: 1,
    pergunta: '🥛 Qual elemento está no copo de leite para deixar nossos ossos e dentes bem fortes?',
    respostaCorretaSimbolo: 'Ca',
    opcoes: ['Ca', 'Fe', 'Au', 'He'],
    explicacao: 'Muito bem! O Cálcio (Ca) está no leite e no queijo, deixando nossos ossos e dentes fortes! 🥛🦴'
  },
  {
    id: 2,
    pergunta: '🎈 Qual gás bem levinho faz os balões de festa flutuarem no ar?',
    respostaCorretaSimbolo: 'He',
    opcoes: ['He', 'Na', 'C', 'Cu'],
    explicacao: 'Isso aí! O gás Hélio (He) é super leve e faz os balões voarem alto! 🎈✨'
  },
  {
    id: 3,
    pergunta: '📱 Qual elemento guarda a energia dentro da bateria recarregável do celular?',
    respostaCorretaSimbolo: 'Li',
    opcoes: ['Li', 'Cl', 'Ag', 'Al'],
    explicacao: 'Parabéns! O Lítio (Li) armazena a energia na bateria do celular e tablet! 📱🔋'
  },
  {
    id: 4,
    pergunta: '🫁 Qual elemento do ar nós respiramos a cada segundo para viver com saúde?',
    respostaCorretaSimbolo: 'O',
    opcoes: ['O', 'Au', 'Ti', 'Hg'],
    explicacao: 'Muito bem! O Oxigênio (O) é o elemento vital do ar que respiramos! 🫁🌱'
  },
  {
    id: 5,
    pergunta: '🧂 Qual elemento dá o sabor salgado no sal de cozinha da nossa comida?',
    respostaCorretaSimbolo: 'Na',
    opcoes: ['Na', 'He', 'F', 'K'],
    explicacao: 'Certo! O Sódio (Na) compõe o sal de cozinha e dá o gostinho na comida! 🧂🍲'
  },
  {
    id: 6,
    pergunta: '🍌 Qual elemento presente na banana ajuda a dar força para os nossos músculos?',
    respostaCorretaSimbolo: 'K',
    opcoes: ['K', 'C', 'Fe', 'Cl'],
    explicacao: 'Muito bem! O Potássio (K) da banana dá energia e protege os músculos! 🍌💪'
  },
  {
    id: 7,
    pergunta: '✏️ Qual elemento faz o grafite escuro da ponta do lápis de escrever e desenhar?',
    respostaCorretaSimbolo: 'C',
    opcoes: ['C', 'Li', 'Ca', 'Au'],
    explicacao: 'Isso! O Carbono (C) forma o grafite macio do lápis para escrevermos e desenharmos! ✏️🎨'
  },
  {
    id: 8,
    pergunta: '🪥 Qual elemento da pasta de dente protege a nossa boca contra as cáries?',
    respostaCorretaSimbolo: 'F',
    opcoes: ['F', 'He', 'Cu', 'Na'],
    explicacao: 'Muito bem! O Flúor (F) fortalece os dentes na escovação diária! 🪥🦷'
  },
  {
    id: 9,
    pergunta: '🧃 Qual metal prateado e levinho é usado para fazer as latinhas de suco e refrigerante?',
    respostaCorretaSimbolo: 'Al',
    opcoes: ['Al', 'Fe', 'O', 'Ca'],
    explicacao: 'Parabéns! O Alumínio (Al) é um metal leve e reciclável que faz latinhas de bebidas! 🧃♻️'
  },
  {
    id: 10,
    pergunta: '🏊 Qual elemento mantém a água da piscina sempre limpa e higienizada?',
    respostaCorretaSimbolo: 'Cl',
    opcoes: ['Cl', 'K', 'Au', 'Li'],
    explicacao: 'Isso aí! O Cloro (Cl) purifica a água da piscina para podermos nadar com segurança! 🏊💧'
  },
  {
    id: 11,
    pergunta: '🥇 Qual metal amarelo e brilhante é usado nas medalhas de primeiro lugar?',
    respostaCorretaSimbolo: 'Au',
    opcoes: ['Au', 'Ag', 'C', 'H'],
    explicacao: 'Muito bem! O Ouro (Au) é o metal amarelo mais precioso e reluzente! 🥇✨'
  },
  {
    id: 12,
    pergunta: '🥈 Qual metal prateado e reluzente faz as medalhas de 2º lugar e lindos anéis?',
    respostaCorretaSimbolo: 'Ag',
    opcoes: ['Ag', 'Na', 'He', 'F'],
    explicacao: 'Certo! A Prata (Ag) é um metal nobre usado em joias, anéis e medalhas! 💍🥈'
  },
  {
    id: 13,
    pergunta: '🧲 Qual metal forte faz pregos de aço e está no prato de feijão para nos dar energia?',
    respostaCorretaSimbolo: 'Fe',
    opcoes: ['Fe', 'Cu', 'O', 'Li'],
    explicacao: 'Isso! O Ferro (Fe) faz ferramentas de aço e dá força ao sangue no corpo! 🧲🍛'
  },
  {
    id: 14,
    pergunta: '🔌 Qual metal avermelhado conduz a eletricidade dentro dos fios da nossa casa?',
    respostaCorretaSimbolo: 'Cu',
    opcoes: ['Cu', 'Al', 'Ca', 'He'],
    explicacao: 'Muito bem! O Cobre (Cu) transporta a energia elétrica com muita eficiência pelos fios! 🔌⚡'
  },
  {
    id: 15,
    pergunta: '💧 Qual elemento se junta com o oxigênio para formar a água (H2O) que bebemos?',
    respostaCorretaSimbolo: 'H',
    opcoes: ['H', 'Au', 'Cl', 'K'],
    explicacao: 'Parabéns! O Hidrogênio (H) se combina com o oxigênio e forma a água fresca que bebemos! 💧🥤'
  },
  {
    id: 16,
    pergunta: '💡 Qual gás brilhante ilumina de vermelho e colorido os letreiros das lojas?',
    respostaCorretaSimbolo: 'Ne',
    opcoes: ['Ne', 'Fe', 'C', 'Na'],
    explicacao: 'Muito bem! O Neônio (Ne) brilha com cores vivas e alegres nos letreiros noturnos! 💡🔴'
  },
  {
    id: 17,
    pergunta: '🩹 Qual elemento está presente na pomada curativa para ajudar a sarar machucados na pele?',
    respostaCorretaSimbolo: 'Zn',
    opcoes: ['Zn', 'Au', 'He', 'O'],
    explicacao: 'Isso aí! O Zinco (Zn) acelera a cicatrização e protege a nossa pele! 🩹👶'
  },
  {
    id: 18,
    pergunta: '💻 Qual elemento da areia da praia é usado para produzir os chips de computadores?',
    respostaCorretaSimbolo: 'Si',
    opcoes: ['Si', 'Li', 'Ca', 'Ag'],
    explicacao: 'Certo! O Silício (Si) da areia é a base para fabricar os processadores e chips eletrônicos! 💻'
  },
  {
    id: 19,
    pergunta: '✈️ Qual metal super resistente e leve é usado na fabricação de aviões e foguetes?',
    respostaCorretaSimbolo: 'Ti',
    opcoes: ['Ti', 'Na', 'Cl', 'F'],
    explicacao: 'Muito bem! O Titânio (Ti) é forte como aço, super leve e não enferruja! ✈️🚀'
  },
  {
    id: 20,
    pergunta: '🥫 Qual elemento protege o interior das latinhas de milho e ervilha contra ferrugem?',
    respostaCorretaSimbolo: 'Sn',
    opcoes: ['Sn', 'Au', 'He', 'Cu'],
    explicacao: 'Parabéns! O Estanho (Sn) reveste a folha de flandres para conservar os alimentos enlatados! 🥫🌽'
  },
  {
    id: 21,
    pergunta: '🌿 Qual elemento gasoso é o mais abundante no ar e ajuda as plantas e hortas a crescerem?',
    respostaCorretaSimbolo: 'N',
    opcoes: ['N', 'Au', 'Fe', 'Li'],
    explicacao: 'Excelente! O Nitrogênio (N) compõe a maior parte do ar e nutre as plantas e árvores! 🌿🌱'
  },
  {
    id: 22,
    pergunta: '🔥 Qual elemento químico está na cabeça do palito de fósforo para acender a chama?',
    respostaCorretaSimbolo: 'P',
    opcoes: ['P', 'He', 'Ca', 'Ne'],
    explicacao: 'Muito bem! O Fósforo (P) produz a faísca segura ao riscar o palito na caixa! 🔥'
  },
  {
    id: 23,
    pergunta: '🧅 Qual elemento natural dá o cheirinho característico no alho e na cebola da cozinha?',
    respostaCorretaSimbolo: 'S',
    opcoes: ['S', 'Cu', 'Al', 'Na'],
    explicacao: 'Isso aí! O Enxofre (S) é o responsável pelo aroma marcante do alho e da cebola! 🧅🧄'
  },
  {
    id: 24,
    pergunta: '🍃 Qual elemento fica no coração das folhas verdes para capturar a luz do Sol?',
    respostaCorretaSimbolo: 'Mg',
    opcoes: ['Mg', 'Ag', 'Au', 'Cl'],
    explicacao: 'Certo! O Magnésio (Mg) fica no centro da clorofila e dá a cor verde às folhas! 🍃☀️'
  },
  {
    id: 25,
    pergunta: '🩺 Qual elemento nutritivo é adicionado ao sal de cozinha para proteger a saúde da tireoide?',
    respostaCorretaSimbolo: 'I',
    opcoes: ['I', 'Fe', 'C', 'He'],
    explicacao: 'Muito bem! O Iodo (I) no sal iodado é essencial para o funcionamento do nosso corpo! 🩺'
  },
  {
    id: 26,
    pergunta: '🛡️ Qual metal pesado é usado nos aventais de proteção na hora do exame de Raio-X?',
    respostaCorretaSimbolo: 'Pb',
    opcoes: ['Pb', 'Na', 'O', 'K'],
    explicacao: 'Parabéns! O Chumbo (Pb) é muito denso e bloqueia a radiação no consultório médico! 🛡️'
  },
  {
    id: 27,
    pergunta: '💍 Qual metal prateado nobre e valioso é usado em anéis de luxo e filtros antipoluição?',
    respostaCorretaSimbolo: 'Pt',
    opcoes: ['Pt', 'H', 'F', 'Li'],
    explicacao: 'Isso! A Platina (Pt) é um metal precioso muito resistente que não desbota! 💍✨'
  },
  {
    id: 28,
    pergunta: '🪙 Qual metal durável e brilhante compõe as moedas de dinheiro que usamos nas compras?',
    respostaCorretaSimbolo: 'Ni',
    opcoes: ['Ni', 'He', 'Ne', 'O'],
    explicacao: 'Muito bem! O Níquel (Ni) torna as moedas resistentes ao desgaste no dia a dia! 🪙'
  },
  {
    id: 29,
    pergunta: '🔦 Qual gás brilhante é colocado dentro de lâmpadas potentes e flashes de fotografia?',
    respostaCorretaSimbolo: 'Kr',
    opcoes: ['Kr', 'Na', 'Ca', 'Fe'],
    explicacao: 'Certo! O Criptônio (Kr) gera uma luz branca bem intensa em lâmpadas especiais! 🔦📸'
  },
  {
    id: 30,
    pergunta: '🚗 Qual gás nobre produz o feixe de luz azulada e potente nos faróis modernos dos carros?',
    respostaCorretaSimbolo: 'Xe',
    opcoes: ['Xe', 'C', 'Al', 'K'],
    explicacao: 'Muito bem! O Xenônio (Xe) ilumina estradas e ruas escuras nos faróis automotivos! 🚗💡'
  },
  {
    id: 31,
    pergunta: '🥣 Qual elemento é misturado ao vidro para fazer travessas e tigelas que vão ao forno?',
    respostaCorretaSimbolo: 'B',
    opcoes: ['B', 'Au', 'Cl', 'Ag'],
    explicacao: 'Parabéns! O Boro (B) dá resistência térmica ao vidro para não quebrar no forno quente! 🥣🔥'
  },
  {
    id: 32,
    pergunta: '🎨 Qual elemento dá uma linda cor azul-marinho e azul-escuro nas tintas de artesanato?',
    respostaCorretaSimbolo: 'Co',
    opcoes: ['Co', 'Li', 'He', 'F'],
    explicacao: 'Isso aí! O Cobalto (Co) produz o famoso tom Azul Cobalto na pintura e em azulejos! 🎨'
  },
  {
    id: 33,
    pergunta: '🌰 Qual elemento saudável está na castanha-do-pará para proteger as células do nosso corpo?',
    respostaCorretaSimbolo: 'Se',
    opcoes: ['Se', 'Ti', 'Cu', 'Na'],
    explicacao: 'Muito bem! O Selênio (Se) é um poderoso protetor natural do nosso organismo! 🌰'
  },
  {
    id: 34,
    pergunta: '🚿 Qual metal espelhado e reluzente reveste as torneiras e chuveiros do banheiro?',
    respostaCorretaSimbolo: 'Cr',
    opcoes: ['Cr', 'C', 'O', 'H'],
    explicacao: 'Certo! O Cromo (Cr) dá o brilho espelhado e impede que a torneira enferruje! 🚿✨'
  },
  {
    id: 35,
    pergunta: '🧲 Qual elemento é usado para fazer os ímãs super fortes que colam recados na geladeira?',
    respostaCorretaSimbolo: 'Nd',
    opcoes: ['Nd', 'Cl', 'K', 'Al'],
    explicacao: 'Parabéns! O Neodímio (Nd) cria os ímãs mais fortes e potentes do mundo! 🧲📋'
  },
  {
    id: 36,
    pergunta: '🚨 Qual elemento seguro fica no detector de fumaça do teto para nos avisar de emergências?',
    respostaCorretaSimbolo: 'Am',
    opcoes: ['Am', 'Fe', 'Na', 'Ca'],
    explicacao: 'Muito bem! O Amerício (Am) vigia o ar nos sensores de fumaça de escolas e shoppings! 🚨'
  },
  {
    id: 37,
    pergunta: '💎 Qual elemento puro da natureza forma os diamantes mais brilhantes do planeta?',
    respostaCorretaSimbolo: 'C',
    opcoes: ['C', 'Au', 'Ag', 'Li'],
    explicacao: 'Isso! O Carbono (C) sob alta pressão na Terra se transforma em diamantes reluzentes! 💎'
  },
  {
    id: 38,
    pergunta: '🌡️ Qual metal prateado e líquido era usado em termômetros de vidro tradicionais?',
    respostaCorretaSimbolo: 'Hg',
    opcoes: ['Hg', 'Cu', 'O', 'Ti'],
    explicacao: 'Certo! O Mercúrio (Hg) é o único metal que é líquido na temperatura ambiente! 🌡️'
  },
  {
    id: 39,
    pergunta: '🥚 Qual elemento mineral forma a casca durinha do ovo e a casinha dos caracóis?',
    respostaCorretaSimbolo: 'Ca',
    opcoes: ['Ca', 'He', 'F', 'Fe'],
    explicacao: 'Muito bem! O Cálcio (Ca) forma o carbonato de cálcio das cascas de ovos e conchas! 🥚🐚'
  },
  {
    id: 40,
    pergunta: '🪞 Qual metal brilhante é colocado atrás do vidro para refletir nossa imagem no espelho?',
    respostaCorretaSimbolo: 'Ag',
    opcoes: ['Ag', 'K', 'Cl', 'Sn'],
    explicacao: 'Parabéns! A Prata (Ag) forma a película espelhada que reflete com perfeição! 🪞✨'
  },
  {
    id: 41,
    pergunta: '🚲 Qual metal leve e durável é usado para fazer o quadro resistente de bicicletas?',
    respostaCorretaSimbolo: 'Al',
    opcoes: ['Al', 'Au', 'Ne', 'Li'],
    explicacao: 'Muito bem! O Alumínio (Al) torna as bicicletas leves, ágeis e fáceis de pedalar! 🚲'
  },
  {
    id: 42,
    pergunta: '🍳 Qual elemento ajuda a formar a camada antiaderente da frigideira para o ovo não grudar?',
    respostaCorretaSimbolo: 'F',
    opcoes: ['F', 'Fe', 'Na', 'Ca'],
    explicacao: 'Certo! O Flúor (F) compõe o revestimento antiaderente que facilita cozinhar! 🍳'
  },
  {
    id: 43,
    pergunta: '🔔 Qual metal de tom avermelhado é usado para fundir grandes sinos e estátuas de praça?',
    respostaCorretaSimbolo: 'Cu',
    opcoes: ['Cu', 'He', 'O', 'H'],
    explicacao: 'Isso aí! O Cobre (Cu) dá o som cristalino aos sinos e compõe o bronze das estátuas! 🔔'
  },
  {
    id: 44,
    pergunta: '🏗️ Qual metal resistente faz as vigas de aço usadas para construir pontes e prédios altos?',
    respostaCorretaSimbolo: 'Fe',
    opcoes: ['Fe', 'Ag', 'Au', 'Cl'],
    explicacao: 'Muito bem! O Ferro (Fe) é o principal ingrediente do aço para erguer construções seguras! 🏗️'
  },
  {
    id: 45,
    pergunta: '☀️ Qual é o elemento mais leve do universo que alimenta a luz e o calor do Sol?',
    respostaCorretaSimbolo: 'H',
    opcoes: ['H', 'Li', 'C', 'Zn'],
    explicacao: 'Parabéns! O Hidrogênio (H) é o combustível das estrelas e do nosso Sol! ☀️🌟'
  }
];

// Função que embaralha uma lista (Fisher-Yates shuffle)
export function embaralharArray<T>(array: T[]): T[] {
  const copia = [...array];
  for (let i = copia.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copia[i], copia[j]] = [copia[j], copia[i]];
  }
  return copia;
}

// Elementos muito conhecidos do cotidiano ideais para distratores fáceis
const ELEMENTOS_POPULARES = ['H', 'He', 'Li', 'C', 'N', 'O', 'F', 'Ne', 'Na', 'Al', 'Si', 'Cl', 'K', 'Ca', 'Fe', 'Cu', 'Zn', 'Ag', 'Au'];

// Gerador dinâmico de perguntas com base em qualquer elemento dos 118 em formato acessível e simples
export function gerarPerguntaDinamicaParaElemento(elemento: ChemicalElement, todosElementos: ChemicalElement[]): QuizQuestion {
  // Escolher distratores conhecidos
  const outrosSimbolos = ELEMENTOS_POPULARES.filter((s) => s !== elemento.simbolo);
  const distratoresSimbolos = embaralharArray(outrosSimbolos).slice(0, 3);
  const opcoesEmbaralhadas = embaralharArray([elemento.simbolo, ...distratoresSimbolos]);

  const exemploUso = elemento.ondeEsta && elemento.ondeEsta.length > 0 ? elemento.ondeEsta[0] : elemento.uso;
  const pergunta = `${elemento.icone || '🧪'} Em qual item do cotidiano encontramos o elemento ${elemento.nome.toUpperCase()} (${elemento.simbolo})?`;

  return {
    id: Math.floor(Math.random() * 1000000),
    pergunta,
    respostaCorretaSimbolo: elemento.simbolo,
    opcoes: opcoesEmbaralhadas,
    explicacao: `Muito bem! O elemento ${elemento.nome} (${elemento.simbolo}) está presente em: ${exemploUso}.`
  };
}

// Gera um conjunto novo e variado de perguntas para o Quiz a cada carregamento ou reinício
export function obterPerguntasSorteadas(quantidade: number = 10): QuizQuestion[] {
  // 1. Embaralhar as perguntas artesanais super fáceis e concretas do banco base
  const perguntasBaseEmbaralhadas = embaralharArray(BANCO_PERGUNTAS_BASE);

  // 2. Garantir opções embaralhadas em cada pergunta base
  const perguntasBaseFormatadas: QuizQuestion[] = perguntasBaseEmbaralhadas.map((p, idx) => ({
    ...p,
    id: idx + 1,
    opcoes: embaralharArray(p.opcoes),
  }));

  // 3. Pegar perguntas do banco adaptado (1 a 10)
  return perguntasBaseFormatadas.slice(0, quantidade).map((p, index) => ({
    ...p,
    id: index + 1,
  }));
}
